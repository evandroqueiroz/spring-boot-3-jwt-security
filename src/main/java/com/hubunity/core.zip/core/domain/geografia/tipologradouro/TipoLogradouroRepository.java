package com.hubunity.core.domain.geografia.tipologradouro;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoLogradouroRepository extends JpaRepository<TipoLogradouro, String> {
}
