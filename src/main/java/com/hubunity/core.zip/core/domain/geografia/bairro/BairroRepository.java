package com.hubunity.core.domain.geografia.bairro;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BairroRepository extends JpaRepository<Bairro, String> {
}
