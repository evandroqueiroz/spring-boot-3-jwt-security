package com.hubunity.core.domain.pessoapapeis;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PessoaPapelRepository extends JpaRepository<PessoaPapel, String> {
}
