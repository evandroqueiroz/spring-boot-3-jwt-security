package com.hubunity.core.domain.geografia.cep;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CepRepository extends JpaRepository<Cep, String> {
}
