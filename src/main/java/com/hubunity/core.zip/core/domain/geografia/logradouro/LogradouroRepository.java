package com.hubunity.core.domain.geografia.logradouro;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LogradouroRepository extends JpaRepository<Logradouro, String> {
}
