package com.hubunity.core.domain.dicsituacao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SituacaoRepository extends JpaRepository<Situacao, String> {
}
