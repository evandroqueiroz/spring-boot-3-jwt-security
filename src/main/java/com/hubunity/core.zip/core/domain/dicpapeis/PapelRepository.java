package com.hubunity.core.domain.dicpapeis;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PapelRepository extends JpaRepository<Papel, String> {
}
