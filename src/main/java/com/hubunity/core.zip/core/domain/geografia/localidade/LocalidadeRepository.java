package com.hubunity.core.domain.geografia.localidade;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalidadeRepository extends JpaRepository<Localidade, String> {
}
