package com.hubunity.core.domain.geografia.distrito;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DistritoRepository extends JpaRepository<Distrito, String> {
}
