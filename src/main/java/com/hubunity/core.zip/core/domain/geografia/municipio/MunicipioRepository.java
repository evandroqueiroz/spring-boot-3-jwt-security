package com.hubunity.core.domain.geografia.municipio;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MunicipioRepository extends JpaRepository<Municipio, String> {
}
