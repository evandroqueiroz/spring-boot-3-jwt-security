package com.hubunity.core.security.token;

public enum TokenType {
  BEARER
}
